package modele.game.game_objects;

public enum PlayerType {
	HUMAN, AI;
}

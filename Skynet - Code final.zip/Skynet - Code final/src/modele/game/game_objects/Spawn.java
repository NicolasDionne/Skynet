package modele.game.game_objects;


public interface Spawn<T> {

    T spawn(short size);

}

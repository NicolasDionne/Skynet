package modele.game;


public interface Update {

    /**
    *
    *   Méthode qui met à jour la position et les paramètres de tous les éléments de jeu.
    *
    */
    void update();

}

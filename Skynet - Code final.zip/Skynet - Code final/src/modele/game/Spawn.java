package modele.game;

public interface Spawn {

	/**
	*
	* Méthode qui fait apparaître des ennemis.
	*
	*/
	void spawn();

}

package tests.ai.coeur.entree;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import ai.coeur.Neurone;
import ai.coeur.entree.SommeImportance;

@SuppressWarnings("all")
public class SommeImportanceTest {

	@Before
	public void setUp() throws Exception {
		SommeImportance sI1 = new SommeImportance();
	}

	@Test
	public void testGetSortieArrayListOfLien() {
		Neurone jusquA = new Neurone();
		fail("Not yet implemented");
	}

	@Test
	public void testGetSortieDoubleArrayDoubleArray() {
		fail("Not yet implemented");
	}

}
